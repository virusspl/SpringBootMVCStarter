  var READTHEDOCS_DATA = {
    project: "bootstrap-datepicker",
    version: "latest",
    language: "en",
    subprojects: {},
    canonical_url: "http://bootstrap-datepicker.readthedocs.io/en/latest/",
    theme: "sphinx_rtd_theme",
    builder: "sphinx",
    docroot: "/docs/",
    source_suffix: ".rst",
    api_host: "https://readthedocs.org",
    commit: "6d7a7e70"
  };
  